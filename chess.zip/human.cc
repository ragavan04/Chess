#include "human.h"

Human::Human(const string& colour, string playerType) : Player(colour, playerType){}

